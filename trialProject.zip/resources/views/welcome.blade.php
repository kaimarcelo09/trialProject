@extends('students.layout')
@section('content')
    <div class="container">
        <div class="row" style="margin: 20px;">
            <div class="col-12">
                <div>
                    <h2>Home</h2>                       
                </div>
            </div>
        </div>
    </div>
@endsection