
<?php $__env->startSection('content'); ?>
    <div class="card mt-5">
        <div class="card-header"><h2>Messages</h2></div>
        <div class="card-body">
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $item->message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <table class="table">
                    <tr>
                        <td>
                            <h4><?php echo e($msg->msg); ?></h4>
                            <?php echo e($item->created_at); ?>

                            <?php echo e($item->name); ?>

                        </td>
                    </tr>
                </table>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KodeGo\trialProject\resources\views/messages/index.blade.php ENDPATH**/ ?>