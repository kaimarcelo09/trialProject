
<?php $__env->startSection('content'); ?>
    <div class="card mt-5">
        <div class="card-header">Students Page</div>
        <div class="card-body">
            <div class="card-body">
                <img src="<?php echo e(asset($students->image)); ?>" height="100" class="img"><br>
                <h5 class="card-title">Name : <?php echo e($students->name); ?> </h5>
                <p class="card-text">Address : <?php echo e($students->address); ?></p>
                <p class="card-text">Mobile : <?php echo e($students->mobile); ?></p>
            </div>
        </div>
    </div>
    <div class="card mt-5">
        <div class="card-header">Messages</div>
        <div class="card-body">
            <table class="table">
                <?php if(count($messages) > 0): ?>
                <tr>
                <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                    
                    <td><h5><?php echo e($item->msg); ?></h5>
                    <small>Written on <?php echo e($item->created_at); ?></small>
                    <td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?> 
                    <small>No Messages from this contact</small>
                <?php endif; ?>
            </table>           
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KodeGo\trialProject\resources\views/students/show.blade.php ENDPATH**/ ?>