<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row" style="margin: 20px;">
            <div class="col-12">
                <div>
                    <h2>Home</h2>                       
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KodeGo\trialProject\resources\views/welcome.blade.php ENDPATH**/ ?>